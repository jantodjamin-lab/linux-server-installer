#!/usr/bin/env python3
import argparse
import json
from core import PROFILES, inventory, plan


def main():
    parser = argparse.ArgumentParser(description='Universal Linux Installer; defaults to read-only dry-run')
    parser.add_argument('--profile', choices=PROFILES, required=True)
    parser.add_argument('--audit', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    report = plan(args.profile, inventory())
    print(json.dumps(report, sort_keys=True, indent=2))
    return int(report['status'] == 'FAIL')


if __name__ == '__main__':
    raise SystemExit(main())
