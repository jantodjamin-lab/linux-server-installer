# Universal Linux Installer V1

Development candidate. Local, manually launched Ubuntu 26.04 installer.
No remote execution. Python 3.11+ and POSIX shell required.

Read-only audit / dry-run (default):

```sh
sh installer/install.sh --profile APP --audit
sh installer/install.sh --profile DB --dry-run
sh installer/install.sh --profile APP+DB
python3 -B -W error::ResourceWarning -m unittest discover -s installer/tests
```

JSON goes to stdout; redirect to a new private evidence file when needed.
Exit 0 means PASS/WARN, 1 FAIL, 2 invalid CLI. WARN never authorizes installation.
No existing database, SSH, firewall, users or services are silently reconfigured.

Offline engine API and safety limits: [compatibility](docs/COMPATIBILITY.md) and
[operator runbook](docs/RUNBOOK.md). The default CLI performs inventory only;
Engine accepts an injected fixture runner. LiveRunner always rejects execution.
The 1.0.0-rc.1 archive is a development candidate, not a complete production release.
Rebuild with `python3 -B installer/release/build.py`.
